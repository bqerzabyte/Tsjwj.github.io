# Neon Light Glowing Text Animation Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/kimo0/pen/Bayqjbg](https://codepen.io/kimo0/pen/Bayqjbg).

